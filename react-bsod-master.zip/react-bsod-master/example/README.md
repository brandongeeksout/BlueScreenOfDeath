# react-bsod Example

## Setup

```
cd example
npm install
```

## Build

```
npm run build
```

## View

Open the `index.html` file in your favourite browser. You should see
`react-bsod` take over the page like below;

<img src="http://i.imgur.com/C5YMxXE.png" alt="blue screen of death" width="700" />
